from gurobipy import *

v0 = [(1,0,20),(1,2,20),(0,1,0),(0,2,0)] #me:positions of the v0  #qua 2
multiv0 = [(1,2,20),(0,1,0)] #me:  the position of the v0 in the input state that participate in creating the v0v1 
multiv1 = [(1,0,21),(1,2,21),(1, 0, 31),(1, 1, 31)] #me: ? positions of the v1 
v0s = [(1,1,0),(1,2,31)] #me: the positions before first chi that v0s exist and participate in the creation of v0v1 
v1s = [(1,2,0),(1,0,31)] #me: the positions before first chi that v1s exist and participate in the creation of v0v1 
multiVars = [(1,0,0),(1,1,31)] #me: the positions of the creation of the kernel quadreatic term after the chi #qua2


lanesize = 32
minOrMax = 'Minimize'
dim = 31


parityTemplate = [
(1, 1, 1, -2, 0, 0),\
(0, 0, 0, -1, 0, 1),\
(-1, 0, 0, 1, 0, 0),\
(0, -1, 0, 1, 0, 0),\
(0, 0, -1, 1, 0, 0)]


#me: as the same as ling's paper, table A1 equations A2 in the paper
chiTemplate = [
(-1,-1,0,0,0,0,0,0,1),\
(-1,0,0,0,0,0,0,1,0),\
(0,0,-1,0,-1,0,0,0,1),\
(0,-1,0,-1,0,0,0,0,1),\
(-1,-1,0,0,0,0,-1,1,1),\
(1,0,0,-1,0,-1,0,-1,2),\
(1,0,0,0,-1,0,1,-1,1),\
(1,1,1,0,0,0,0,-1,0),\
(0,-1,-1,1,1,0,0,1,0),\
(0,-1,-1,0,1,1,0,1,0)]

#me: as the same as ling's paper, table A2 equations A3 in the paper
chi2Template = [(-1, 0, -1, -1, 0, 0, 2),    
(-1, 0, -1, 0, 0, 1, 1),
(-1, 0, 0, -1, 1, 0, 1),
(-1, 0, -1, 0, -1, 0, 2),
(-1, 0, 0, -1, 0, -1, 2),
(-1, -1, -1, 0, 0, 0, 2)]


def constraintsOfKeyCapacity(a):####need change
	'''
	me: the key bits have to be zero in the milp model
	'''
	constraint = []
	ts=zeroState()
	for i in range(32):
		laneindex=11
		constraint.append(a[laneindex%4][laneindex//4][i%lanesize] + ' = 0') 
		
	return constraint


def vars_state(s):
	"""generate vars of size 5*5*lanesize  """
	
	#me: generating vars state size  4*3*lanesize
	
	a = []
	for x in range(4):
		col = []
		for y in range(3):
			col.append( [s+'_'+str(x)+'_'+str(y)+'_'+str(z) for z in range(lanesize)] )
		a.append(col)
	return a

def vars_plane(s):#copied
	"""  generate vars of size 5*lanesize   """
	#me: generating vars for the columns size 4*lanesize
	d = []
	for x in range(4):
		d.append([s+'_'+str(x)+'_'+str(z) for z in range(lanesize)])
	return d
	

def vars_dummy(): #copied
	'''
	me: adding the new vars used for conditions to the milp (these vars take degree of freedom and also the type of them
	should be added to the model-Binary section-)
	'''
	ind_set=[]

	num=4
	print ("dummynum",num)
	dummy = ['e' +str(i) for i in range(num)]
	return dummy


def getVariables_From_Constraints(C): #copied
	#me: extracts all of the vars from the constraints
	V = set([])
	for s in C:
		temp = s.strip()
		temp = temp.replace('+', ' ')
		temp = temp.replace('-', ' ')
		temp = temp.replace('>=', ' ')
		temp = temp.replace('<=', ' ')
		temp = temp.replace('=', ' ')
		temp = temp.replace('>', ' ')
		temp = temp.replace('<', ' ')
		temp = temp.split()
		for v in temp:
			if not v.isdigit():
				V.add(v)
	return V

def theta(a): #copied
	#me: theta operation in 
	C = []
	D = []
	for x in range(4):
		C.append([0 for z in range(lanesize)])
		D.append([0 for z in range(lanesize)])

	for x in range(4):
		for z in range(lanesize):
			for y in range(3):
				C[x][z] ^= a[x][y][z]
	for x in range(4):
		E = rot(C[(x+3)%4], 5)
		F = rot(C[(x+3)%4], 14)
		for z in range(lanesize):
			D[x][z] = E[z]^F[z]
	for x in range(4):
		for z in range(lanesize):
			for y in range(3):
				a[x][y][z] ^= D[x][z]
	return a


def rot(x, r): #copied
	"""Bitwise rotation (to the left) of r bits considering the \
	string of bits is lanesize bits long"""
	r = r%lanesize
	return x[lanesize-r:lanesize] + x[0:lanesize-r]


def RhoWest(A): #copied
	B = zeroState()
	for x in range(4):
		B[x][0] = A[x][0]
		B[x][1] = A[(x-1)%4][1]
		B[x][2] = rot(A[x][2], 11)
	return B

def RhoEast(A): #copied
	B = zeroState()
	for x in range(4):
		B[x][0] = A[x][0]
		B[x][1] = rot(A[x][1], 1)
		B[x][2] = rot(A[(x-2)%4][2], 8)
	return B

def inv_rot(x, r): #copied
	"""Bitwise rotation (to the left) of r bits considering the \
	string of bits is lanesize bits long"""
	r = r%lanesize
	return x[r:lanesize] + x[0:r]

def inv_RhoWest(A): #copied
	B = zeroState() 
	for x in range(4):
		B[x][0] = A[x][0]
		B[x][1] = A[(x+1) % 4][1]
		B[x][2] = inv_rot(A[x][2], 11)
	return B
#can be omited
def constraintsOfV0V1Init(a, v0, v1): #copied
	#me the positions for v0 and v1 are already taken and should not be a potential position for the ordinary cube vars
	constraint = []
	for (x,y,z) in v0:
		constraint.append(a[x][0][z] + ' + ' + a[x][1][z] + ' + ' + a[x][2][z] + ' = 0 ') 
	for (x,y,z) in v1:
		constraint.append(a[x][y][z] + ' = 0')
	return constraint




def genFromConstraintTemplate(vars_list, ineq_template): #copied
	#me generating inequalities from the variables and template
	"""
	Example:
		>>> ConstraintGenerator.genFromConstraintTemplate(['x0', 'x1'], ['y0'], [(-1, 2, 3, 1), (1, -1, 0, -2)] )
		['-1 x0 + 2 x1 + 3 y0 >= - 1', '1 x0 - 1 x1 + 0 y0 >= 2']
		>>> ConstraintGenerator.genFromConstraintTemplate(['x0', 'x1'], ['y0'], [(-1, 2, 3, 1), (-1, -1, 0, -2)] )
		['-1 x0 + 2 x1 + 3 y0 >= - 1', '-1 x0 - 1 x1 + 0 y0 >= 2']
	"""
	assert ineq_template != list([])
	assert (len(vars_list)) == (len(ineq_template[1]) - 1)

	constraints = list([])
	for T in ineq_template:
		s = str(T[0]) + ' ' + vars_list[0]
		for j in range(1, len(vars_list)):
			if T[j] >= 0:
				s = s + ' + ' + str(T[j]) + ' ' + vars_list[j]
			elif T[j] < 0:
				s = s + ' - ' + str(-T[j]) + ' ' + vars_list[j]
		s = s + ' >= '
		if T[-1] <= 0:
			s = s + str(-T[-1])
		elif T[-1] > 0:
			s = s + '- ' + str(T[-1])
		constraints.append(s)
	return constraints

def constraintsOfTheta(a, b, F, G):#copied
	'''
	me: creates the first theta constraints  
	and also the inequalities number (1) in the ling paper
	the inputs of this functions are (a, b, F, G)
	'''
	constraints = []

	# constraints of column sums
	for x in range(4):
		for z in range(lanesize):
			sum = []
			for y in range(3):
				sum.append(a[x][y][z])
			constraints += genFromConstraintTemplate(sum + [F[x][z], G[x][z]], parityTemplate)
			

	'''
	for x in range(4):
		for z in range(lanesize):
			for y in range(3):
				constraints.append(b[x][y][z]+' - '+a[x][y][z]+' >= 0')
				constraints.append(b[x][y][z]+' - '+G[(x+3)%4][(z+lanesize-5)%lanesize]+' >= 0')
				constraints.append(b[x][y][z]+' - '+G[(x+3)%4][(z+lanesize-14)%lanesize]+' >= 0')
				constraints.append(a[x][y][z]+ ' + ' +G[(x+3)%4][(z+lanesize-5)%lanesize] + ' + '+G[(x+3)%4][(z+lanesize-14)%lanesize] + ' - ' +b[x][y][z] + ' >= 0' )
	'''

	'''
	since the cp-kernel is our interest, the above inequalities should be replaced with a[x][y][z] = b[x][y][z] 
	'''
	for x in range(4):
		for y in range(3):
			for z in range(lanesize):
				constraints.append(b[x][y][z]+' - '+a[x][y][z]+' = 0')
	
	return constraints

def zeroState(): 
	
	#me: generates the state of xoodo and fill them with 0
	a = []
	for x in range(4):
		col = []
		for y in range(3):
			col.append( [0 for z in range(lanesize)] )
		a.append(col)
	return a

def loadVars(Vars):#########################
	#me: generates a zero state and puts 1 for position of the each var in Vars (Vars = multiVars)
	a = zeroState()
	for (x,y,z) in Vars:
		a[x][y][z] = 1
	return a

def loadv0v1(v0,v1):
	#me: generates a new state and puts 1 for the positions of the v0 and v1
	a = zeroState()
	for (x,y,z) in v0:
		a[x][y][z] = 1
	for (x,y,z) in v1:
		a[x][y][z] = 1
	return a

def minusv0sv1s(a,v0s,v1s):
	'''
	me: finds the positions before first chi contains v0 or v1 and prints them
	minus the positions of v0s and v1s
	and prints it again
	hint -> the v0 and v1 that are not participated in creation of the kernel quadratic v0v1
	should not mutiplied with any-thing else, so in their coulumn they should be the only variable
	this function returns those positions
	'''

	for x in range(4):
		for y in range(3):
			for z in range(lanesize):
				if a[x][y][z]:
					print (x,y,z)
	for (x,y,z) in v0s:
		a[x][y][z] = 0
	for (x,y,z) in v1s:
		a[x][y][z] = 0
	print ("middle")
	for x in range(4):
		for y in range(3):
			for z in range(lanesize):
				if a[x][y][z]:
					print (x,y,z)


def genConObj(): 
	'''
	me: generates the summation of all of v[x][y][z]
	it is used for objective function once it is minimiization and also the constraints the summation
	should be greater-equal than 1
	'''
	v = vars_state('v')
	sum = []
	for i in range(12):
		x=i%4
		y=i//4
		for z in range(lanesize):
			sum.append(v[x][y][z])
	return ' + '.join(sum)

def genDimObj(): #copied
	'''
	me: it is used once the objection is maximization
	'''
	a = vars_state('a')
	F = vars_plane('f')
	sum = []
	consumption = []
	for x in range(4):
		for y in range(3):
			sum += a[x][y]
	FD = ' + '.join(sum)
	for x in range(4):
		consumption += F[x]
	objective = FD + ' - '+ ' - '.join(consumption)
	dummy = vars_dummy()
	objective = objective + ' - ' + ' - '.join(dummy)

	return objective

def genDimCon(a, F): #copied
	'''
	me: creating the constraint: sum(a[z][y][z]) -sum(f[x][z]) - sum(e) = 2^(n+1)-1
	'''
	sum = []
	consumption = []
	for x in range(4):
		for y in range(3):
			sum += a[x][y]
	FD = ' + '.join(sum)
	for x in range(4):
		consumption += F[x]
	objective = FD + ' - '+ ' - '.join(consumption)
	dummy = vars_dummy()
	objective = objective + ' - ' + ' - '.join(dummy)

	return objective + ' = ' + str(dim)
	

def writeFile(name, C, V): #copied
	'''
    me: writes the model
    '''
	f = open(name, 'w')
	f.write(minOrMax+'\n')

	if minOrMax == 'Minimize':
		f.writelines(genConObj())
	else:
		f.writelines(genDimObj())

	f.write('\n\n')
	f.write('Subject To\n')
	for c in C:
		f.write(c)
		f.write('\n')
	f.write('\n')

	f.writelines(genConObj()+' >= 1\n')

	f.write('Binary\n')
	for v in V:
		f.write(v)
		f.write('\n')
		

	f.close()



def constraintsofRound():#copied
	'''
    me: creates the constraints for first round 
    '''
	constraints=[]
	a = vars_state('a')
	b = vars_state('b')
	F = vars_plane('f')
	G = vars_plane('g')
	

	constraints += constraintsOfKeyCapacity(a)
	constraints += constraintsOfV0V1Init(a, v0, multiv1)#me the positions for v0 and v1 should not be a potential position for the ordinary cube vars
	constraints += constraintsOfTheta(a, b, F, G)

	b = RhoWest(b)
	v = vars_state('v')
	h = vars_state('h')
	c = vars_state('c')
	v0v1Mask = loadv0v1(v0,multiv1)  #me: creating a zerostate and puting the positions of v0 and v1 in it

	
	dummy = vars_dummy()
	#1 round
	
	
	A1T=theta(v0v1Mask)####
	A1RW=RhoWest(A1T)

	minusv0sv1s(A1RW,v0s,v1s)
	'''
	me: finding the positions of v0 and v1 before first chi that are not participated in the creation of the kernel v0v1
	and making them as an only variable in their column
	'''
	for x in range(4):
		for y in range(3):
			for z in range(lanesize):
				if A1RW[x][y][z]:
					#22bitleftandright
					constraints.append(b[x][(y+2)%3][z] + ' = 0')
					constraints.append(b[x][(y+1)%3][z] + ' = 0')
	
	
	'''
	me: creating chi constraint
	it should be notted for the positions that kernel quadratic are created (multiVars)
	the chi constraints are different:
	b for the column should be zero 
	c for the column should be zero, execept the position of multiVars
	v for the column should be lower equal than 1
	h for the column should be lower equal than 1 
	'''
	for x in range(4):
		for z in range(lanesize):
			
			if ((z==multiVars[0][2]) and (x==multiVars[0][0])) or ((z==multiVars[1][2]) and (x==multiVars[1][0])): #multiVars = [(1,0,0),(1,1,31)]
				#need changed according to multiIndex!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
				if (z==multiVars[0][2]) and (x==multiVars[0][0]):
					y=multiVars[0][1]
				else:
					y=multiVars[1][1]

				
				#me: hint-> rhowest is imposed on b, so the indices are not in order 
				constraints.append(b[x][y][z]+' = 0')
				constraints.append(b[x][(y+1)%3][z]+' = 0')#56
				constraints.append(b[x][(y+2)%3][z]+' = 0')#56,both57
				
				
				constraints.append(c[x][y][z]+' = 1')
				constraints.append(c[x][(y+1)%3][z]+' = 0')
				constraints.append(c[x][(y+2)%3][z]+' = 0')
				
				constraints.append(v[x][y][z]+' <= 1')
				constraints.append(v[x][(y+1)%3][z]+' <= 1')
				constraints.append(v[x][(y+2)%3][z]+' <= 1')

				
				constraints.append(h[x][y][z]+' <= 1')#non limit
				constraints.append(h[x][(y+1)%3][z]+' <= 1')#non limit
				constraints.append(h[x][(y+2)%3][z]+' <= 1')#non limit
							
				
			else:
			
				for y in range(3):
					#print y,z
					constraints += genFromConstraintTemplate([b[x][y][z], b[x][(y+1)%3][z], b[x][(y+2)%3][z], v[x][(y+1)%3][z], v[x][(y+2)%3][z], h[x][(y+1)%3][z], h[x][(y+2)%3][z], c[x][y][z]], chiTemplate)
	
	'''
	me: finding the positions of the kernel quadratic term before the second chi
	'''
	c=RhoEast(c)	
	#2 round
	MULT=loadVars(multiVars) #me: multiVars --> the positions of the creation of the kernel quadreatic term after the chi
	A2RW=RhoWest(theta(RhoEast(MULT))) #me: input of the second chi

	cnt=0
	for i in range(12): #me: finding the number of the kernel quadratic term before the second chi(which actually has to be 2)
		for j in range(lanesize):
			if RhoEast(MULT)[i%4][i//4][j]:
				cnt+=1
	print ("cnt:",cnt)
	

	'''
	me: creating a zero state, and finding the positions of the kernel term before the second chi and
	making nonzero the rest of the positions of the columns that contain kernel  
	hint --> the neighboring bits of the kernel terms before the second chi should be constant
	'''
	nemult=zeroState()
	for x in range(4):
		for y in range(3):
			for z in range(lanesize):
				if A2RW[x][y][z] == 1: 
					nemult[x][(y+1)%3][z]=1
					nemult[x][(y+2)%3][z]=1

	'''
	me: creating the second chi constraints
	'''
	NEMULT=inv_RhoWest(nemult) #me: output of the second theta with the neighboring positions of the quadratic terms
	print(NEMULT)
	ind=0
	#DUMMY num 4
	for x in range(4):
		for y in range(3):
			for z in range(lanesize):
				if NEMULT[x][y][z] == 1:
					print ("dummy",ind)
					print(x+4*y,z, z + 32*(x+4*y))
					sum = []
					sum.append(c[x][y][z])
					print (dummy[ind])
					print (c[x][y][z])
					constraints.append(dummy[ind] + ' - ' + c[x][y][z] + ' >= 0' ) #me: c is output of the first round
					constraints += genFromConstraintTemplate([dummy[ind], b[x][y][z], b[x][(y+1)%3][z], b[x][(y+2)%3][z], v[x][(y+1)%3][z], v[x][(y+2)%3][z]], chi2Template)
					for yy in range(3):
						sum.append(c[(x+3)%4][yy][(z-5)%lanesize])
						sum.append(c[(x+3)%4][yy][(z-14)%lanesize])
						constraints.append(dummy[ind] + ' - ' + c[(x+3)%4][yy][(z-5)%lanesize] + ' >= 0' )
						constraints.append(dummy[ind] + ' - ' + c[(x+3)%4][yy][(z-14)%lanesize] + ' >= 0' )
						constraints += genFromConstraintTemplate([dummy[ind], b[(x+3)%4][yy][(z-5)%lanesize], b[(x+3)%4][(yy+1)%3][(z-5)%lanesize], b[(x+3)%4][(yy+2)%3][(z-5)%lanesize], v[(x+3)%4][(yy+1)%3][(z-5)%lanesize], v[(x+3)%4][(yy+2)%3][(z-5)%lanesize]], chi2Template)
						constraints += genFromConstraintTemplate([dummy[ind], b[(x+3)%4][yy][(z-14)%lanesize], b[(x+3)%4][(yy+1)%3][(z-14)%lanesize], b[(x+3)%4][(yy+2)%3][(z-14)%lanesize], v[(x+3)%4][(yy+1)%3][(z-14)%lanesize], v[(x+3)%4][(yy+2)%3][(z-14)%lanesize]], chi2Template)
					constraints.append(' + '.join(sum) + ' - ' + dummy[ind] + ' >= 0')
					#print dummy[ind],sum
					ind += 1
	
	if minOrMax == 'Minimize':
		constraints.append(genDimCon(a,F))

	return constraints


def genModel(): #copied
	V = set([])
	C = list([])
	
	C = C + constraintsofRound()
	V = getVariables_From_Constraints(C)

	name = 'MILP_Model_for_6round_Xoodyak'
	writeFile(name + '.lp',C,V)
	m = read(name + '.lp')
	m.optimize()
	

	if m.status == 2:
		print (m.ObjVal)
		m.write(name + '.sol')
		cnt=0
		for v in m.getVars():
			if (v.x == 1) and (v.VarName[0]=='a'):
				print(v.VarName)
				cnt+=1
		print ("jishu",cnt)
		############readSol(name + '.sol', conditionalVars)
		return m.ObjVal
	return 0

if __name__ == '__main__':
	genModel()
			

