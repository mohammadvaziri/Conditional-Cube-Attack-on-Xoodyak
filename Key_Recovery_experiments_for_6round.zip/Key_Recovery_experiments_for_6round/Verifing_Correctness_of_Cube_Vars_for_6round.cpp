/*
for runing this code on a linux cluster, first determine the number of the cores on "CORES_num" then write the following commands
g++ -o main_omp -fopenmp Verifing_Correctness_of_Cube_Vars_for_6round.cpp
./main_omp
*/

#include <stdio.h>
//#include <conio.h> //uncomment this if you are runung the program in windows
#include <curses.h>
#include <string.h>
#include <stdlib.h>
#include <chrono> //for printing elapssed time 
#include <iostream>
#include <fstream>
#include <omp.h>
using namespace std;


typedef unsigned char UINT8; //me: is used for rightkey and condition key (according to the bit conditions it could be a 2,4,5,6 bits word), one char is one byte (8bits)
typedef unsigned short int UINT16;//me: is not used in this program
typedef signed long long int INT64;//me: long integer, one of its application is using in the main zero-sum for loop (2^33)

#define random(x) (rand())%x;
#define nrRounds 6
#define nrLanes 12
#define LOOP_ITERS 	(INT64(1) << 33)
#define LOOP_SIZE	76  //the number of the related keys
#define OPENMP_LOOP
#define CORES_num	64  //the number of the cores for the cluster

void XoodooPermutationOnWords(uint32_t *state);
void theta(uint32_t *A);
void rho_west(uint32_t *A);
void chi(uint32_t *A);
void rho_east(uint32_t *A);

void XoodooPermutationOnWords(uint32_t *state)
{
	unsigned int i;

	for (i = 0; i<nrRounds; i++) {
		theta(state);
		rho_west(state);
		chi(state);
		rho_east(state);
		//iota(state, i);
	}
}

//me: x is the column index and y is the row index of the lane, examp-> index(1,2)=9(lane number9)
#define index(x, y) (  ((x)%4) + 4*((y)%3)  )

//me:a is a lane (or xor of the 3 lanes in a column for the theta), and offset is the amount of rotation(i.e 5 or 14) in the lane  
#define ROL32(a, offset) (   (offset != 0)  ?  (  ( ((uint32_t)a) << offset ) ^ ( ((uint32_t)a) >> (32-offset) )  )  :  a   )


//me: A is the whole state which contains 12 32-bits lanes
void theta(uint32_t *A)
{
	unsigned int x, y;//me:column index (x) and row index (y) of the lanes 
	uint32_t C[4], D[4];//me: C[i] is the Xors of the three lanes in  the ith column.
					  //me: D[i] is the rotated Xors (<<5, and <<14)of the three lanes in  the ith column.

	for (x = 0; x<4; x++) {
		C[x] = 0;
		for (y = 0; y<3; y++)
			C[x] ^= A[index(x, y)];
	}
	for (x = 0; x<4; x++)
		D[x] = ROL32(C[(x - 1) % 4], 5) ^ ROL32(C[(x - 1) % 4], 14);
	for (x = 0; x<4; x++)
		for (y = 0; y<3; y++)
			A[index(x, y)] ^= D[x];
}

void rho_west(uint32_t *A)
{
	unsigned int x;

	//me: imposing the rotation on the second row
	uint32_t C;
	C = A[index(3, 1)];//me: lane number 7
	for (x = 3; x>0; x--)
		A[index(x, 1)] = A[index(x - 1, 1)];
	A[index(0, 1)] = C;

	//me: imposing the rotation on the third row
	for (x = 0; x<4; x++)
		A[index(x, 2)] = ROL32(A[index(x, 2)], 11);
}

void chi(uint32_t *A)
{
	unsigned int x, y; // me: column index(x) and row index(y) of the lanes
	uint32_t C[3];//me: c[y] is the result of chi operation in the yith row for each lane in the ith column

	for (x = 0; x<4; x++) {
		for (y = 0; y<3; y++)
			C[y] = A[index(x, y)] ^ ((~A[index(x, y + 1)]) & A[index(x, y + 2)]);
		for (y = 0; y<3; y++)
			A[index(x, y)] = C[y];
	}
}
void rho_east(uint32_t *A)
{
	unsigned int x;
	uint32_t C, D;
	//me: third row 
	C = A[index(0, 2)];//me: lane number 8
	D = A[index(1, 2)];//me: lane number 9
					   //for the 3rd row (lanes number 8,9,10,11) 2 rotation on the lanes are applied, and 8-bits rotation should be applied in each lane 
	A[index(0, 2)] = ROL32(A[index(2, 2)], 8);//me: lane number 8, (lane number 8 is replaced with rotated lane num 10)
	A[index(1, 2)] = ROL32(A[index(3, 2)], 8);//me: lane number 9, (lane number 9 is replaced with rotated lane num 11)
	A[index(2, 2)] = ROL32(C, 8);//me: lane number 10, (lane number 10 is replaced with rotated lane num 8)
	A[index(3, 2)] = ROL32(D, 8);//me: lane number 11, (lane number 11 is replaced with rotated lane num 9)

								 //me: second row
								 //me: 1-bits rotation should be applied in each lane 
	for (x = 0; x<4; x++)
		A[index(x, 1)] = ROL32(A[index(x, 1)], 1);
}


int main()
{
	uint32_t InitialState[12] = { 0 };
	uint32_t Key[12] = { 0 };
	int i, t, tempkey, temp;
	INT64 j;
	UINT8 rightkey;
	FILE *f;
	f = fopen("result.txt", "w");
	fclose(f);

	//me: the first element of each array shows the index(0-11) of lane, the second one shows the position in the lane
	unsigned int index[70][2];
	index[0][0] = 1; index[0][1] = 20; //(1,20)-->A[1][0][20] = v0
	index[1][0] = 4; index[1][1] = 0; //(4,0)-->A[0][1][0] = v0
	index[2][0] = 8; index[2][1] = 0; //(8,0)-->A[0][2][0] = v0
	index[3][0] = 9; index[3][1] = 20; //(9,20)-->A[1][2][20] = v0
	index[4][0] = 1; index[4][1] = 21; //(1,21)-->A[1][0][21] = v1
	index[5][0] = 1; index[5][1] = 31; //(1,31)-->A[1][0][31] = v1
	index[6][0] = 5; index[6][1] = 31; //(5,31)-->A[1][1][31] = v1
	index[7][0] = 9; index[7][1] = 21; //(9,21)-->A[1][2][21] = v1
	index[8][0] = 4; index[8][1] = 3; //(4,3)-->A[0][1][3] = v2
	index[9][0] = 8; index[9][1] = 3; //(8,3)-->A[0][2][3] = v2
	index[10][0] = 0; index[10][1] = 9; //(0,9)-->A[0][0][9] = v3
	index[11][0] = 8; index[11][1] = 9; //(8,9)-->A[0][2][9] = v3
	index[12][0] = 4; index[12][1] = 9; //(4,9)-->A[0][1][9] = v4
	index[13][0] = 8; index[13][1] = 9; //(8,9)-->A[0][2][9] = v4
	index[14][0] = 0; index[14][1] = 12; //(0,12)-->A[0][0][12] = v5
	index[15][0] = 4; index[15][1] = 12; //(4,12)-->A[0][1][12] = v5
	index[16][0] = 0; index[16][1] = 23; //(0,23)-->A[0][0][23] = v6
	index[17][0] = 8; index[17][1] = 23; //(8,23)-->A[0][2][23] = v6
	index[18][0] = 4; index[18][1] = 23; //(4,23)-->A[0][1][23] = v7
	index[19][0] = 8; index[19][1] = 23; //(8,23)-->A[0][2][23] = v7
	index[20][0] = 0; index[20][1] = 24; //(0,24)-->A[0][0][24] = v8
	index[21][0] = 8; index[21][1] = 24; //(8,24)-->A[0][2][24] = v8
	index[22][0] = 4; index[22][1] = 24; //(4,24)-->A[0][1][24] = v9
	index[23][0] = 8; index[23][1] = 24; //(8,24)-->A[0][2][24] = v9
	index[24][0] = 0; index[24][1] = 30; //(0,30)-->A[0][0][30] = v10
	index[25][0] = 4; index[25][1] = 30; //(4,30)-->A[0][1][30] = v10
	index[26][0] = 1; index[26][1] = 2; //(1,2)-->A[1][0][2] = v11
	index[27][0] = 9; index[27][1] = 2; //(9,2)-->A[1][2][2] = v11
	index[28][0] = 1; index[28][1] = 11; //(1,11)-->A[1][0][11] = v12
	index[29][0] = 5; index[29][1] = 11; //(5,11)-->A[1][1][11] = v12
	index[30][0] = 1; index[30][1] = 14; //(1,14)-->A[1][0][14] = v13
	index[31][0] = 9; index[31][1] = 14; //(9,14)-->A[1][2][14] = v13
	index[32][0] = 1; index[32][1] = 22; //(1,22)-->A[1][0][22] = v14
	index[33][0] = 9; index[33][1] = 22; //(9,22)-->A[1][2][22] = v14
	index[34][0] = 2; index[34][1] = 2; //(2,2)-->A[2][0][2] = v15
	index[35][0] = 10; index[35][1] = 2; //(10,2)-->A[2][2][2] = v15
	index[36][0] = 6; index[36][1] = 2; //(6,2)-->A[2][1][2] = v16
	index[37][0] = 10; index[37][1] = 2; //(10,2)-->A[2][2][2] = v16
	index[38][0] = 2; index[38][1] = 5; //(2,5)-->A[2][0][5] = v17
	index[39][0] = 10; index[39][1] = 5; //(10,5)-->A[2][2][5] = v17
	index[40][0] = 6; index[40][1] = 5; //(6,5)-->A[2][1][5] = v18
	index[41][0] = 10; index[41][1] = 5; //(10,5)-->A[2][2][5] = v18
	index[42][0] = 6; index[42][1] = 8; //(6,8)-->A[2][1][8] = v19
	index[43][0] = 10; index[43][1] = 8; //(10,8)-->A[2][2][8] = v19
	index[44][0] = 2; index[44][1] = 9; //(2,9)-->A[2][0][9] = v20
	index[45][0] = 10; index[45][1] = 9; //(10,9)-->A[2][2][9] = v20
	index[46][0] = 6; index[46][1] = 9; //(6,9)-->A[2][1][9] = v21
	index[47][0] = 10; index[47][1] = 9; //(10,9)-->A[2][2][9] = v21
	index[48][0] = 6; index[48][1] = 11; //(6,11)-->A[2][1][11] = v22
	index[49][0] = 10; index[49][1] = 11; //(10,11)-->A[2][2][11] = v22
	index[50][0] = 2; index[50][1] = 12; //(2,12)-->A[2][0][12] = v23
	index[51][0] = 10; index[51][1] = 12; //(10,12)-->A[2][2][12] = v23
	index[52][0] = 6; index[52][1] = 12; //(6,12)-->A[2][1][12] = v24
	index[53][0] = 10; index[53][1] = 12; //(10,12)-->A[2][2][12] = v24
	index[54][0] = 2; index[54][1] = 14; //(2,14)-->A[2][0][14] = v25
	index[55][0] = 10; index[55][1] = 14; //(10,14)-->A[2][2][14] = v25
	index[56][0] = 6; index[56][1] = 14; //(6,14)-->A[2][1][14] = v26
	index[57][0] = 10; index[57][1] = 14; //(10,14)-->A[2][2][14] = v26
	index[58][0] = 6; index[58][1] = 16; //(6,16)-->A[2][1][16] = v27
	index[59][0] = 10; index[59][1] = 16; //(10,16)-->A[2][2][16] = v27
	index[60][0] = 2; index[60][1] = 24; //(2,24)-->A[2][0][24] = v28
	index[61][0] = 10; index[61][1] = 24; //(10,24)-->A[2][2][24] = v28
	index[62][0] = 6; index[62][1] = 24; //(6,24)-->A[2][1][24] = v29
	index[63][0] = 10; index[63][1] = 24; //(10,24)-->A[2][2][24] = v29
	index[64][0] = 2; index[64][1] = 30; //(2,30)-->A[2][0][30] = v30
	index[65][0] = 6; index[65][1] = 30; //(6,30)-->A[2][1][30] = v30
	index[66][0] = 3; index[66][1] = 1; //(3,1)-->A[3][0][1] = v31
	index[67][0] = 7; index[67][1] = 1; //(7,1)-->A[3][1][1] = v31
	index[68][0] = 3; index[68][1] = 25; //(3,25)-->A[3][0][25] = v32
	index[69][0] = 7; index[69][1] = 25; //(7,25)-->A[3][1][25] = v32
	
	

	//srand(100); //me: seeding a pseudo random number generator used by the rand() function
	for (i = 0; i<LOOP_SIZE; i++)//key
	{

		for (j = 0; j<12; j++) {
			Key[j] = 0;//me: note that key is a 6 32-bits word
		}

		//=============me: generating the key and printing it in the result file, and inserting the key-bit condition in cond==========
		unsigned int cnt = 0;//me: is a counter
		UINT8 cond = 0;//me: is used for filling each key-bit condition in the related member
		for (j = 0; j<12; j++) {
			for (t = 0; t<32; t++) {
				temp = random(2);//me: creating a random bit

				//state[10][26] = k(67) + k(90) + k(104) + k(195) + k(218) + k(323) + k(346) + v(67) + v(90) + v(104) + v(195) + v(218) + v(323)
				if (cnt == 67 || cnt == 90 || cnt == 104 || cnt == 195 || cnt == 218 || cnt == 323 || cnt == 346) {
					cond += temp;
				}

				if (temp)
				{
					Key[j] ^= ((uint32_t)0x1 << t);//me: example --> ((UINT32)0x1 << 2) ==  00000000000000000000000000000100
				}
				else {
				}
				cnt++;
			}
		}
		//=============me: end of generating the key and printing it in the result file, and inserting the key-bit condition in cond====
		for (j = 0; j<12; j++) {
			InitialState[j] = Key[j];//refereshing the initial state			
		}

		//cout<<"initial state:"<<endl;
		//printf("0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n\n", InitialState[0], InitialState[1], InitialState[2], InitialState[3], InitialState[4], InitialState[5], InitialState[6], InitialState[7], InitialState[8], InitialState[9], InitialState[10], InitialState[11]);

		
		//====================me: inserting the bit condition after guessing the key===============
		rightkey = cond & 1;
		tempkey = rightkey ^ 1;
		if(tempkey){
			InitialState[10]^=((uint32_t)0x1<<26);
		}
		//====================me: end of inserting the bit condition after guessing the key==============

		//printf("0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n", InitialState[0], InitialState[1], InitialState[2], InitialState[3], InitialState[4], InitialState[5], InitialState[6], InitialState[7], InitialState[8], InitialState[9], InitialState[10], InitialState[11]);

		//me: two dimentional array for parallerizing (the number of the cores in the cluster is 64)
		uint32_t TempState[CORES_num][12] = { 0 };//me: is going to be filled every time with the new value of the cube vars and the determined key, 
		uint32_t FinalState[CORES_num][12] = { 0 };//me:  this array is the sumation of the all TempState states
		uint32_t FinalFinalState[12]; //me: this array is created to avoid confilict between the cores
		
		auto start = chrono::steady_clock::now();

		#ifdef OPENMP_LOOP //me: parallerizing
			#pragma omp parallel for
		#endif
		
		for (j = 0; j<LOOP_ITERS; j++)//initialize tempstate  me: j<(INT64(1) << 33 is 2^33 repeating
		{
			INT64 k;
			for (k = 0; k<12; k++)//fresh the tempstate 
			{
				TempState[omp_get_thread_num()][k] = InitialState[k];
			}
			

			//give the value for cube variables
			uint32_t cubev[33] = { 0 };
			uint32_t statev[70] = { 0 };
			for (k = 0; k<33; k++)//creating all possible values for 33 cube vars (0<=j<2^33)
			{
				cubev[k] = (j >> k) & 1;
			}

			statev[0] = cubev[0];  //v0
			statev[1] = cubev[0];  //v0
			statev[2] = cubev[0];  //v0
			statev[3] = cubev[0];  //v0
			statev[4] = cubev[1];  //v1
			statev[5] = cubev[1];  //v1
			statev[6] = cubev[1];  //v1
			statev[7] = cubev[1];  //v1
			statev[8] = cubev[2];  //v2
			statev[9] = cubev[2];  //v2
			statev[10] = cubev[3];  //v3
			statev[11] = cubev[3];  //v3
			statev[12] = cubev[4];  //v4
			statev[13] = cubev[4];  //v4
			statev[14] = cubev[5];  //v5
			statev[15] = cubev[5];  //v5
			statev[16] = cubev[6];  //v6
			statev[17] = cubev[6];  //v6
			statev[18] = cubev[7];  //v7
			statev[19] = cubev[7];  //v7
			statev[20] = cubev[8];  //v8
			statev[21] = cubev[8];  //v8
			statev[22] = cubev[9];  //9
			statev[23] = cubev[9];  //v9
			statev[24] = cubev[10];  //v10
			statev[25] = cubev[10];  //v10
			statev[26] = cubev[11];  //v11
			statev[27] = cubev[11];  //v11
			statev[28] = cubev[12];  //v12
			statev[29] = cubev[12];  //v12
			statev[30] = cubev[13];  //v13
			statev[31] = cubev[13];  //v13
			statev[32] = cubev[14];  //v14
			statev[33] = cubev[14];  //v14
			statev[34] = cubev[15];  //v15
			statev[35] = cubev[15];  //v15
			statev[36] = cubev[16];  //v16
			statev[37] = cubev[16];  //v16
			statev[38] = cubev[17];  //v17
			statev[39] = cubev[17];  //v17
			statev[40] = cubev[18];  //v18
			statev[41] = cubev[18];  //v18
			statev[42] = cubev[19];  //v19
			statev[43] = cubev[19];  //v19
			statev[44] = cubev[20];  //v20
			statev[45] = cubev[20];  //v20
			statev[46] = cubev[21];  //v21
			statev[47] = cubev[21];  //v21
			statev[48] = cubev[22];  //v22
			statev[49] = cubev[22];  //v22
			statev[50] = cubev[23];  //v23
			statev[51] = cubev[23];  //v23
			statev[52] = cubev[24];  //v24
			statev[53] = cubev[24];  //v24
			statev[54] = cubev[25];  //v25
			statev[55] = cubev[25];  //v25
			statev[56] = cubev[26];  //v26
			statev[57] = cubev[26];  //v26
			statev[58] = cubev[27];  //v27
			statev[59] = cubev[27];  //v27
			statev[60] = cubev[28];  //v28
			statev[61] = cubev[28];  //v28
			statev[62] = cubev[29];  //v29
			statev[63] = cubev[29];  //v29
			statev[64] = cubev[30];  //v30
			statev[65] = cubev[30];  //v30
			statev[66] = cubev[31];  //v31
			statev[67] = cubev[31];  //v31
			statev[68] = cubev[32];  //v32
			statev[69] = cubev[32];  //v32
			


			for (k = 0; k<70; k++)//inserting each cube var in TempState
			{	
				if (statev[k]) {
					TempState[omp_get_thread_num()][index[k][0]] ^= uint32_t(1) << index[k][1];
				}
			}

			XoodooPermutationOnWords((uint32_t *)TempState[omp_get_thread_num()]);

			//cout<<"\nafter permutation"<<endl;
			//printf("0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n", TempState[0], TempState[1], TempState[2], TempState[3], TempState[4], TempState[5], TempState[6], TempState[7], TempState[8], TempState[9], TempState[10], TempState[11]);

			for (k = 0; k<12; k++) {//adding the TempState with FinalState
				FinalState[omp_get_thread_num()][k] ^= TempState[omp_get_thread_num()][k];
			}
		}


		for (j = 0; j < CORES_num; j++) {
			for (t = 0; t < 12; t++) {
				FinalFinalState[t] ^= FinalState[j][t]; 
			}
		}

		f = fopen("result.txt", "a");

		fprintf(f,"%d-th experiment:\n",i+1);
		printf(" %d-th experiment:\n",i+1);
		fprintf(f, "Random generated key:\n0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n", Key[0], Key[1], Key[2], Key[3], Key[4], Key[5], Key[6], Key[7], Key[8], Key[9], Key[10], Key[11]);
		printf("Random generated key:\n0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n", Key[0], Key[1], Key[2], Key[3], Key[4], Key[5], Key[6], Key[7], Key[8], Key[9], Key[10], Key[11]);
		fprintf(f, "Right key: 0x%x\n", rightkey);
		printf("Right key: 0x%x\n", rightkey);
		fprintf(f, "Cube sum:\n0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n", FinalFinalState[0], FinalFinalState[1], FinalFinalState[2], FinalFinalState[3], FinalFinalState[4], FinalFinalState[5], FinalFinalState[6], FinalFinalState[7], FinalFinalState[8], FinalFinalState[9], FinalFinalState[10], FinalFinalState[11]);
		printf("Cube sum:\n0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x, 0x%x\n", FinalFinalState[0], FinalFinalState[1], FinalFinalState[2], FinalFinalState[3], FinalFinalState[4], FinalFinalState[5], FinalFinalState[6], FinalFinalState[7], FinalFinalState[8], FinalFinalState[9], FinalFinalState[10], FinalFinalState[11]);
		auto finish = chrono::steady_clock::now();
		fprintf(f, "Total Elapsed Time : %ld min\n\n\n", chrono::duration_cast<chrono::minutes>(finish - start).count());
		printf("Total Elapsed Time : %ld min\n\n\n", chrono::duration_cast<chrono::minutes>(finish - start).count());	
		fclose(f);
		
	}

	return 0;
}
